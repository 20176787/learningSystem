const ChatRoomModel =require("../models/ChatRoomModel");
const updateChatList=require("./chatListController");
const clearUserUnreadCount=require("./unreadCountController");
const saveRoomAndUpdateChatList = async (
    body,
    res,
    chatRoom,
    isNewChat
) => {
        await chatRoom.save();
        // Update Room ID as mongodb row ID
        await ChatRoomModel.updateOne(
            { _id: chatRoom._id },
            { $set: { roomId: chatRoom._id } }
        );

        updateChatList(body, res, chatRoom, isNewChat);
};
module.exports = saveRoomAndUpdateChatList;
