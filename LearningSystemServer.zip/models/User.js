const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const jwt= require("jsonwebtoken");
const config= require("config");
//create a schema
const UserSchema = new Schema(
    {
      userId: {type: String, required: false},
      userName: {
        type: String,
        required: true
      },
      email: {
        type: String,
        required: true
      },
      password: {
        type: String,
        required: true
      },
      date: {
        type: Date,
        default: Date.now
      },
    }  ,{ timestamps: true }
    );
UserSchema.methods.generateAuthToken = function (userId) {
  return jwt.sign({ id: userId ? userId : this._id }, '14071999');
};
const user = mongoose.model('users', UserSchema);
module.exports = user;
