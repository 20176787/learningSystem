const jwt =require("jsonwebtoken");
const config = require("config");

function authUser(req, res, next) {
    //get the token from the header if present
    const token = req.headers["x-access-token"] || req.headers["authorization"];
    //if no token found, return response (without going to the next middelware)
    // const token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjYwYTk1NmE1Mjg5ZWNhMDk0MGYwNDM0ZSIsIm5hbWUiOiJmZGZkc2ZkIiwiaWF0IjoxNjIxNzYyMDc5LCJleHAiOjE2MjE3NjU2Nzl9.aM3pvL79w-sM7ewE84RPNtls1PSXL0A9xVWtY_fwGRw";
    console.log(token);
    if (!token) return res.status(401).send("Access denied, No token provided.");
    try {
        const decoded = jwt.verify(token.split(' ')[1], '14071999',function(err, decoded) {
            console.log(decoded.foo) // bar
        })
        req.user = decoded;
        next();
    } catch (error) {
        //if invalid token
        res.status(400).send("Invalid token.");
    }
};
module.exports = authUser;
