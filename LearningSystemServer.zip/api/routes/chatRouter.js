const express = require("express");
const getUserChatList = require("../../controller/chatListController");
const authUser = require("../../middleware/auth");
const ChatListModel = require("../../models/ChatListModel");
const ChatUnreadCountModel = require("../../models/ChatUnreadCountModel");
const router = express.Router();
router.post("/chatList",authUser,async (req,res)=>{
    const id = req.body.id;
    console.log("USER ID => ", req.body);
    try {
        const chats = await ChatListModel.find({
            $or: [{ userId: id }, { chatId: id }],
        });
        console.log("getUserChatList => ", JSON.stringify(chats));
        if (!chats) {
            return res.status(200).json({ success: false, message: "Api Failed" });
        }

        for (let index = 0; index < chats.length; index++) {
            const element = chats[index];
            let chatUnreadItem = (await ChatUnreadCountModel.findOne({
                roomId: element.roomId,
            }));

            console.log("ChatUnreadCountModel => ",element, chatUnreadItem);

            if (chatUnreadItem && id === chatUnreadItem.chatId1) {
                element.chatUnreadCount = chatUnreadItem.chatId1Count;
            } else if (chatUnreadItem && id === chatUnreadItem.chatId2) {
                element.chatUnreadCount = chatUnreadItem.chatId2Count;
            } else {
                element.chatUnreadCount = 0;
            }
            chats[index] = element;
        }

        console.log("ChatUnreadCount RESPONSE => ", chats);

        return res.status(200).json({ success: true, data: chats });
    } catch (err) {
        return res.status(200).json({ success: false, message: err });
    }
});
module.exports=router;
