const express=require("express");
// const getUserLastSeen=require("../../controller/lastSeenController");
const saveRoomAndUpdateChatList=require("../../controller/chatRoomController");
const clearUserUnreadCount = require("../../controller/unreadCountController");
const router = express.Router();
const ChatRoomModel = require('../../models/ChatRoomModel');
const authUser = require("../../middleware/auth");
router.post("/chatRoom",authUser,async (req, res)=>{
    const roomId = req.body.roomId;
    console.log(req.body);
    try {
        // await clearUserUnreadCount(roomId, userId);
        const chats = await ChatRoomModel.find({ roomId: roomId });
        if (!chats) {
            return res.status(200).json({ success: false, message: "Api Failed" });
        }
        return res.status(200).json({ success: true, data: chats });
    } catch (err) {
        return res.status(200).json({ success: false, message: err });
    }
});
router.post("/createRoom",authUser,  async (req, res)=>{
    const body = req.body;
    console.log('body',body);
    if (!body) {
        return res.status(200).json({
            success: false,
            message: "Invalid Data",
        });
    }
    const chatRoom = new ChatRoomModel(body);
    // Save Chat Room messages
    saveRoomAndUpdateChatList(body, res, chatRoom, true);
});
router.post("/updateRoom",authUser,async (req, res)=>{
    try {
    const body = req.body;
    if (!body) {
        return res.status(200).json({
            success: false,
            message: "Invalid Data",
        });
    }
    ChatRoomModel.findOne({ _id: body.roomId }, async (err, chatRoom) => {
        if (err) {
            return res.status(200).json({
                success: false,
                message: err.message,
            });
        }
        chatRoom.chat.push(body.chat);
        saveRoomAndUpdateChatList(body, res, chatRoom, false);
    });
} catch (error) {
    return res.status(200).json({
        success: false,
        message: error.message,
    });
}
});
router.post("/lastSeen",authUser, async (req, res)=>{
    let paramId = req.body.id;
    try {
        const lastSeen = await LastSeenModel.find({ userId: paramId });
        res.status(200).json({
            success: true,
            lastSeen: lastSeen,
        });
    } catch (error) {
        return res.status(200).json({
            success: false,
            message: error.message,
        });
    }
});
module.exports= router;
