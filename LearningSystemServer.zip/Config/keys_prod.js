module.exports = {
  mongoURI: process.env.MONGO_URI,
  secretOrKey: process.env.SECRET_OR_KEY
}

/*
here the keys for production database and secret.
these will be stored in the env variables in the server side


*/