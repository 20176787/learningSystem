module.exports = {
  mongoURI: "mongodb://localhost:27017/?readPreference=primary&appname=MongoDB%20Compass&ssl=false",
  secretOrKey: "YOURSECRET"
}
