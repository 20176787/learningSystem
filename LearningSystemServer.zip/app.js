const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const passport = require('passport');
const mongoose = require('mongoose');
const socket = require("socket.io");
const auth = require('./api/routes/authRouter');
const chatRouter = require('./api/routes/chatRouter');
const roomRouter = require('./api/routes/roomRouter');
const port = process.env.PORT || 5000;

//body-parser middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

//DB config
const db = require('./config/keys').mongoURI;
//connect to mongodb
mongoose.connect(db, { useNewUrlParser: true })
  .then(() => console.log('database connected'))
  .catch((err) => console.log(err));

//passport middleware
app.use(passport.initialize());

//passport config
require('./config/passport')(passport);


app.use('/api/auth', auth);
app.use("/api/chat", chatRouter);
app.use("/api/room", roomRouter);

const server = app.listen(port, () => console.log(`Server Started at port ${port}`));
const io = socket(server);
io.on("connection", function (socket) {
    socket.on("CHAT_LIST", (msg) => {
        console.log("CHAT_LIST", msg);
        io.emit("CHAT_LIST", msg);
    });
    socket.on("CHAT_ROOM", (msg) => {
        console.log("CHAT_ROOM", msg);
        io.emit("CHAT_ROOM", msg);
    });
    console.log("Made socket connection");
});
